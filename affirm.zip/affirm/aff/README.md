# Salesforce: Get Account details using LWC component
This LWC component displays the Accounts and lets the user select a single Account
and When account is selected then it indicate what Account is selected with details of account

There is one trigger Created on Contact Object in this trigger it pulls a Indutry field from Account and stored into Account_Industry field in Contact object.

